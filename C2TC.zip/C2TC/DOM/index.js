//Accessing document
document;


//Accessing document childs using tree hierarchy
document.firstElementChild;
document.lastElementChild;
document.firstElementChild.firstElementChild;
document.firstElementChild.lastElementChild;
document.firstElementChild.lastElementChild.firstElementChild;
document.firstElementChild.lastElementChild.lastElementChild;
//Accessing nner childs
document.firstElementChild.lastElementChild.children[4];
document.firstElementChild.lastElementChild.children[2];

//Fetching id's
document.getElementById("title"); 
document.getElementById("list");
document.getElementById("atag");

//Fetching classes's
document.querySelector(".btn");
document.querySelector(".item");
document.querySelector("h1");

//Styling
document.querySelector("h1").style.color="red";
document.querySelector("h1").style.color="violet";
document.querySelectorAll("#list .item")[0].style.color="red";
document.querySelectorAll("#list .item")[1].style.color="orange";
document.querySelectorAll("#list .item")[2].style.color="yellow";
document.querySelector("button").style.backgroundColor="red";

//Adding content
document.querySelector("h1").innerHTML="Good Morning";
document.querySelector("h1").innerHTML="<em>Good Morning<em>";

//Fetching Docs using querySelector
document.querySelector(".item1");
document.querySelector(".item2");
document.querySelector(".item3");
let item1=document.querySelector(".item1");
//Removing list
item1.remove();
item1.textContent="java";
let item2=document.querySelector(".item2");
//Changing content
item2.textContent="FullvStak";
document.querySelector("#name");

//Events
nameInput.addEventListener("input",(e)=>
    {
        document.querySelector(".container").append(nameInput.value);
    });


function onSubmit(e)
    {
        e.preventDefault();
    }
console.log(nameInput.value);