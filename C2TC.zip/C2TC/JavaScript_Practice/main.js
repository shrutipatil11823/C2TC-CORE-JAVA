document;

//fetching
//accessing myform
document.getElementById('myform');
//accessing h1 tag
document.querySelector('h1');
//accessing class
document.querySelector('.container');
//accessing list items
const ul=document.querySelector('.items');


//deleting list items
ul.remove();
//removing lst item from list
ul.lastElementChild.remove();


//updating list
ul.firstElementChild.textContent="Item11";//update first item ti Item11
//updating inner or middle items
ul.children[1].innerText="Item12"//update second item ti Item12
ul.children[2].innerText="Item13"//update third item ti Item13


//Accessing button class
const ul=document.querySelector('.button');


//Styling submit button 
button.style.background="red";


//addEventListener to form on console for click event
button.addEventListener('click',(e)=>
    {
       console.log("click");
        e.preventDefault();
    });


// addEventListener to form on console to print nameInput
nameInput.addEventListener("input",(e)=>
    {
        document.querySelector(".container").append(nameInput.value);
    });
const emailInput=document.querySelector("#email");
console.log(nameInput.value);
console.log(emailInputInput.value);


// addEventListener to form on console via ALERT for checking filled details
myform.addEventListener("submit",onSubmit);
//one
if(nameInput.value==='' || emailInput.value==='')
{
    alert("please enter all the fields!");
}else
{
    console.log("success");
}